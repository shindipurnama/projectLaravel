@extends('admin/admin')

@section('judul')
 <center><h2 class="h5 no-margin-bottom">Home</h2></center>
@endsection
@section('konten')
		 <center><img src="welcome5.gif" width="650px" height="400px"></center>
@endsection 