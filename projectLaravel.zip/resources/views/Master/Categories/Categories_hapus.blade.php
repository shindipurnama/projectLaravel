@extends('admin/admin')

@section('judul')
<title>Hapus Edit</title>
@endsection

@section('konten')

@endsection