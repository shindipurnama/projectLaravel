<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Sales</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <style>
        body{
            font-family:'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
            color:#333;
            text-align:left;
            font-size:18px;
            margin:0;
        }
        .container{
            margin:0 auto;
            margin-top:35px;
            padding:0px;
            width:700px;
            height:auto;
            background-color:#fff;
        }
        caption{
            font-size:28px;
            margin-bottom:15px;
        }
        table{
            border:1px solid #333;
            border-collapse:collapse;
            margin:0 auto;
            width:700px;
        }
        td, tr, th{
            padding:2px;
            border:1px solid #333;
            width:100px;
        }
        th{
            background-color: #f0f0f0;
        }
        h4, p{
            margin:0px;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <table>
            <caption>
                Shindi's Store
            </caption>
            
            <thead>
                <tr>
                    <th colspan="4">Invoice <strong>#<?php echo e($sls->NOTA_ID); ?></strong></th>
                    <th><?php echo e($sls->NOTA_DATE); ?></th>
                </tr>
                <tr>
                    <td colspan="3">
                        <h4>Store : </h4>
                        <p>Shindi's Store.<br>
                            JL. Menuju Masa Depan Lebih Baik No. 01<br>
                            Surabaya<br>
                            081343340102<br>
                            Shindi_Store@olshop.com
                        </p>
                    </td>
                    <td colspan="2">
                        <h4>Customer: </h4>
                        <?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php if(($sls->CUSTOMER_ID) == ($cus->CUSTOMER_ID)): ?>
                            <p><?php echo e($cus->FIRST_NAME); ?> <?php echo e($cus->LAST_NAME); ?><br>
                                <?php echo e($cus->PHONE); ?><br>
                                <?php echo e($cus->EMAIL); ?> <br>
                                <?php echo e($cus->STREET); ?> , <?php echo e($cus->CITY); ?> <br>
                                <?php echo e($cus->STATE); ?> , <?php echo e($cus->ZIP_CODE); ?>

                            </p>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                    </td>
                </tr>
                <tr>
                    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(($sls->USER_ID) == ($us->USER_ID)): ?>
                            <th colspan="4">Employee <strong> : <?php echo e($us->FIRST_NAME); ?> <?php echo e($us->LAST_NAME); ?></strong></th>
                            <th>#<?php echo e($us->USER_ID); ?></th>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
            </thead>
            <tbody>
                        <tr>
                            <th>Product Name</th>                                   
                            <th>Quantity</th> 
                            <th>Discount</th>
                            <th>Price</th>
                            <th>Total Price</th>
                        </tr>
            <?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if( ($sls->NOTA_ID) == ($salesdetail->NOTA_ID) ): ?>
                        <?php if( ($salesdetail->PRODUCT_ID) == ($pr->PRODUCT_ID) ): ?>
                        <tr>
                            <td><?php echo e($pr->PRODUCT_NAME); ?></td>    
                            <td><?php echo e($salesdetail->QUANTITY); ?></td>
                            <td>Rp <?php echo e(number_format($salesdetail->DISCOUNT)); ?></td>
                            <td>Rp <?php echo e(number_format($salesdetail->SELLING_PRICE)); ?></td>
                            <td>Rp <?php echo e(number_format($salesdetail->TOTAL_PRICE)); ?></td>
                        </tr>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tfoot>
            <tr>
                    <th colspan="4">Tax</th>
                    <td align="center">10%</td>
                </tr>
                <tr>
                    <th colspan="4">Total Payement</th>
                    <td>Rp <?php echo e(number_format($sls->TOTAL_PAYMENT)); ?></td>
                </tr>
            </tfoot>
        </table>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</body>
</html><?php /**PATH C:\xampp\htdocs\projectLaravel\resources\views/Transaksi/sales/sales_pdf.blade.php ENDPATH**/ ?>