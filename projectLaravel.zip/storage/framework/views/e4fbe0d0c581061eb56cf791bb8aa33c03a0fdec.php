<?php $__env->startSection('judul'); ?>
     <center><h2 class="h5 no-margin-bottom">Customer</h2></center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="col-lg-12">
	<div class="block margin-bottom-sm">
	  <div class="title"><strong>List Of Customer</strong></div>
	  <div class="table-responsive"> 
		 
	<div class="form-group">  
		<table class="table table-striped">
		  <thead>
			<tr>
			  <th>#</th>
			  <th>User Id</th>
			  <th>First Name</th>
			  <th>Last Name</th>                                   
			  <th>Email</th>                        
			  <th>Phone</th>
			  <th>Street</th>
			  <th>City</th>
			  <th>State</th>
			  <th>Zip Code</th> 
			  <th>Status</th>
			  <th>Action</th>
			</tr>
		  </thead>
		  <tbody>
			<?php $no = 1; ?>
		  	<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		  <tr>
			  <td><?php echo e($no++); ?></td>
			  <td><?php echo e($cus->CUSTOMER_ID); ?></td>
			  <td><?php echo e($cus->FIRST_NAME); ?></td>
			  <td><?php echo e($cus->LAST_NAME); ?></td>
			  <td><?php echo e($cus->PHONE); ?></td>
			  <td><?php echo e($cus->EMAIL); ?></td>
			  <td><?php echo e($cus->STREET); ?></td>
			  <td><?php echo e($cus->CITY); ?></td>
			  <td><?php echo e($cus->STATE); ?></td>
			  <td><?php echo e($cus->ZIP_CODE); ?></td>
			  <?php if($cus->CUSTOMER_STATUS == 0): ?>
					<td><span class="badge badge-success">Active</span></td>
				<?php else: ?>
					<td><span class="badge badge-danger">Non-active</span></td>
				<?php endif; ?>
			  <td>
				  <a href="CustomerEdit<?php echo e($cus->CUSTOMER_ID); ?>" class="btn btn-info">Edit</a>
				  <button type="button" data-toggle="modal" data-target="#myModaldel" class="btn btn-danger">Delete</button>
			  </td>
		  </tr>
		  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
	</table>
	<div class="form-group">  
	<center><a href='CustomerCreate'><input type="submit" value="Add New Customer" class="btn btn-primary"></a></center>
		</div>
		</div>
	  </div>
	</div>
</div>
                     
<!-- Modal Hapus SALES -->       
<div id="myModaldel" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
  <div role="document" class="modal-dialog modal-sm">
	<div class="modal-content" >
	  <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Delete Customer</strong>
		<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
	  </div>
	  <div class="modal-body">
	  	h4>Are You Sure To Add This Data?</h4> <br> </h5>I adivse you to change the "Customer Status" rather than delete it</h5>
	  	</div>
	  <div class="modal-footer" >
	  	<center>
		<a href="CustomerDestroy/<?php echo e($cus->CUSTOMER_ID); ?>"><button type="submit" class="btn btn-danger">Yes</button></a>
		<a href="CustomerEdit<?php echo e($cus->CUSTOMER_ID); ?>" class="btn btn-success" >Change Status</a>
		<button type="button" data-dismiss="modal" class="btn btn-info">No</button></center>
	  </div>
	</div>
  </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectLaravel\resources\views/Master/Customer/Customer.blade.php ENDPATH**/ ?>