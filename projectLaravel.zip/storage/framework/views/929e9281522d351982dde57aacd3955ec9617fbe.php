<?php $__env->startSection('judul'); ?>
 <center><h2 class="h5 no-margin-bottom">Sales Detail</h2></center>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<div class="col-lg-12">
	<div class="block margin-bottom-sm">
	  <div class="title"><strong>List Of Sales Detail</strong></div>
	  <div class="table-responsive"> 
		<div class="form-group">  
			<table class="table table-striped">
		  <thead>
			<tr>
			  <th></th>
			  <th>Nota Id</th>
			  <th>Product Id</th>                                   
			  <th>Quality</th>                        
			  <th>Selling Price</th>
			  <th>Discount</th>
			  <th>Total Price</th>
		  </tr>
		</thead>
		<tbody>
				<?php $no = 1; ?>
				<?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr>
				<td><?php echo e($no++); ?></td>
				<td><?php echo e($sd->NOTA_ID); ?></td>
				<td><?php echo e($sd->PRODUCT_ID); ?></td>
				<td><?php echo e($sd->QUANTITY); ?></td>
				<td><?php echo e($sd->SELLING_PRICE); ?></td>
				<td><?php echo e($sd->DISCOUNT); ?></td>
				<td><?php echo e($sd->TOTAL_PRICE); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>
		<center><a href="SalesIndex"><input type="submit" value="Sales" class="btn btn-primary"></a></center>
	 </div>
     </div>
	 </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectLaravel\resources\views/Transaksi/sales_detail/sales_detail.blade.php ENDPATH**/ ?>