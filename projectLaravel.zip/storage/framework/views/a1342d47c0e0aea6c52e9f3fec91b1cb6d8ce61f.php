<?php $__env->startSection('judul'); ?>
 <center><h2 class="h5 no-margin-bottom">Sales</h2></center>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
<div class="col-lg-12">
	<div class="block margin-bottom-sm">
	  <div class="title"><strong>List Of Sales</strong></div>
	  <div class="table-responsive"> 
		 
	<div class="form-group">  
		<table class="table table-striped">
		  <thead>
			<tr>
			  <th></th>
			  <th>Nota Id</th>
			  <th>Customer Id</th>                                   
			  <th>User Id</th>                        
			  <th>Nota Date</th>
			  <th>Total Payment</th>
			  <th>Action</th>
		  </tr>
		</thead>
		<tbody>
			<tr>
			<?php $no = 1; ?>
		  	<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
			  <td><?php echo e($no++); ?></td>
			  <td><?php echo e($sls->NOTA_ID); ?></td>
			  <td><?php echo e($sls->CUSTOMER_ID); ?></td>
			  <td><?php echo e($sls->USER_ID); ?></td>
			  <td><?php echo e($sls->NOTA_DATE); ?></td>
			  <td><?php echo e($sls->TOTAL_PAYMENT); ?></td>
			  <td><input type="submit" value="DETAIL" data-toggle="modal" data-target="#myModal<?php echo e($sls->NOTA_ID); ?>" class="btn btn-danger"></td>
			</tr>
			
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
		</table>
		<center><a href="SalesDetail"><input type="submit" value="Details of Sales Recap" class="btn btn-primary"></a></center>
				  </div>
				  </div>
				  </div>
	 </div>
</div>
			<!-- Modal detail SALES 1-->
			<div id="myModal<?php echo e($sls->NOTA_ID); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
				<div role="document" class="modal-dialog modal-xl">
					<div class="modal-content" >
					<div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Detail View</strong>
						<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
					</div>
					<div class="modal-body">
					
					<?php if( ($sls->NOTA_ID)  ==  ($sls->NOTA_ID) ): ?>
					<duv class="form-inline">
					<div class="col-md-3 col-sm-6">
					<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(($sls->USER_ID) == ($us->USER_ID)): ?>
							<div class="icon-user-1"><strong>User</strong></div>
							<input type="text" disabled="" value="<?php echo e($us->FIRST_NAME); ?> <?php echo e($us->LAST_NAME); ?>" class="form-control">
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>

					<div class="col-md-3 col-sm-6">
					<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if(($sls->CUSTOMER_ID) == ($cus->CUSTOMER_ID)): ?>
							<div class="icon-user-1"><strong>Customer</strong></div>
							<input type="text" disabled="" value="<?php echo e($cus->FIRST_NAME); ?> <?php echo e($cus->LAST_NAME); ?>" class="form-control">
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>

					<div class="col-md-3 col-sm-6">
							<div class="icon-new-file"><strong>Date</strong></div>
							<input type="text" disabled="" value="<?php echo e($sls->NOTA_DATE); ?>" class="form-control">
					</div>

					<div class="col-md-3 col-sm-6">
							<div class="icon-windows"><strong>Date</strong></div>
							<input type="text" disabled="" value="<?php echo e($sls->TOTAL_PAYMENT); ?>" class="form-control">
					</div>
					</div>
						<div class="table-responsive"> 
							<div class="form-group">  
							<table class="table table-striped" id="keranjang" width="100%">
							<thead>
								<tr>
								<th></th>
								<th>Nota Id</th>
								<th>Product Name</th>                                   
								<th>Quantity</th>      
								<th>Discount</th>
								<th>Selling Price</th>
								<th>Total Price</th>
							</tr>
							</thead>
							<tbody>
							<tr>
								<?php $no = 1; ?>
								<?php $__currentLoopData = $sales_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $salesdetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr id="col<?php echo e($loop->iteration); ?>">
									<?php if(($sls->NOTA_ID) == ($salesdetail->NOTA_ID) && (($salesdetail->PRODUCT_ID) == ($pr->PRODUCT_ID)) ): ?>
										<td><?php echo e($no++); ?></td>
										<td><?php echo e($salesdetail->NOTA_ID); ?> </td>  
										<td><?php echo e($pr->PRODUCT_NAME); ?></td>    
										<td><?php echo e($salesdetail->QUANTITY); ?></td>
										<td><?php echo e($salesdetail->DISCOUNT); ?></td>
										<td><?php echo e($salesdetail->SELLING_PRICE); ?></td>
										<td><?php echo e($salesdetail->TOTAL_PRICE); ?></td>
									<?php endif; ?>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								
							</tbody>
							</table>
						</div>
						</div>
					</div>
					<?php endif; ?>
					<div class="modal-footer">
						<button type="button" data-dismiss="modal" class="btn btn-secondary">Close</button>
					</div>
					</div>
				</div>
				</div>
<?php $__env->stopSection(); ?>
		
                  
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectLaravel\resources\views/Transaksi/sales/sales.blade.php ENDPATH**/ ?>