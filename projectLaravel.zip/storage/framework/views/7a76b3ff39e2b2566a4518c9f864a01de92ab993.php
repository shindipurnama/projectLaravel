<?php $__env->startSection('judul'); ?>
 <center><h2 class="h5 no-margin-bottom">Home</h2></center>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('konten'); ?>
		 <center><img src="welcome5.gif" width="650px" height="400px"></center>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kasir/kasir', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectLaravel\resources\views/kasir/home.blade.php ENDPATH**/ ?>