<?php $__env->startSection('judul'); ?>
     <center><h2 class="h5 no-margin-bottom">User Edit</h2></center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="col-lg-12">
	<div class="block margin-bottom-sm">
	 <div class="title"><strong>Please Fill The BOX</strong></div>
		<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $us): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form class="form-horizontal" action="UserUpdate" method="post">
		<?php echo e(@csrf_field()); ?>

	  <div class="form-group row" action="CategoriesStore" method="post">
		<label class="col-sm-3 form-control-label">User Id</label>
		<div class="col-sm-9">
		  <input type="text" value="<?php echo e($us->USER_ID); ?>" class="form-control" name="idus" id="idus">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">First Name</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="firstuser" id="firstuser" value="<?php echo e($us->FIRST_NAME); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Last Name</label>
			<div class="col-sm-9">
		 	 <input type="text" class="form-control" name="lastuser" id="lastuser" value="<?php echo e($us->LAST_NAME); ?>">
			</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
	 	<label class="col-sm-3 form-control-label">Phone</label>
	  	<div class="col-sm-9">
			<input type="text" class="form-control" name="phoneuser" id="phoneuser" value="<?php echo e($us->PHONE); ?>"><small class="help-block-none">Input with number</small>
	 	 </div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Email</label>
		<div class="col-sm-9">
		  <input type="email" class="form-control" name="emailuser" id="emailuser" value="<?php echo e($us->EMAIL); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Password</label>
		<div class="col-sm-9">
		  <input type="password" class="form-control" name="passuser" id="passuser" value="<?php echo e($us->PASSWORD); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Job Status</label>
		<div class="col-sm-9">
			<select name="jsuser" class="form-control mb-3 mb-3" > 
				<?php if($us->JOB_STATUS == 0): ?>
					<option selected  value="0">Active</option>
					<option  value="1">Non - Active</option>
				<?php else: ?>
					<option  value="0">Active</option>
					<option selected  value="1">Non - Active</option>
				<?php endif; ?>
			</select>
		  </div>
	  </div>
	  <div class="line"></div>
			 
	<center><input type="submit"  value="Save" class="btn btn-primary"></td></center>
	</form>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<!-- Modal-->
<div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
  <div role="document" class="modal-dialog modal-sm">
	<div class="modal-content" >
	  <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Add a new User</strong>
		<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
	  </div>
	  <div class="modal-body">
		  <h2>Are You Sure To Add This Data?</h2>
	  </div>
	  <div class="modal-footer">
		<a href="UserIndex"><button type="submit" class="btn btn-primary">Yes</button></a>
		<button type="button" data-dismiss="modal" class="btn btn-info">Add More</button>
	  </div>
	</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\projectLaravel\resources\views/Master/User/User_edit.blade.php ENDPATH**/ ?>