<footer class="footer">
  <div class="footer__block block no-margin-bottom">
	<div class="container-fluid text-center">
	  <!-- Please do not remove the backlink to us unless you support us at https://bootstrapious.com/donate. It is part of the license conditions. Thank you for understanding :)-->
	  <p class="no-margin-bottom">2019 &copy; Your company. Design by <a href="https://bootstrapious.com/p/bootstrap-4-dark-admin">Bootstrapious</a>.</p>
	</div>
  </div>
</footer>