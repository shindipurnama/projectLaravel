<!-- Sidebar Navigation-->
  <nav id="sidebar">
	<!-- Sidebar Header-->
	<div class="sidebar-header d-flex align-items-center">
	  <div class="avatar"><img src="fotoku.jfif" alt="..." class="img-fluid rounded-circle"></div>
	  <div class="title">
		<h1 class="h5">Shindi Purnama Putri</h1>
		<p>Web Designer</p>
	  </div>
	</div>
	<!-- Sidebar Navidation Menus--><span class="heading">Main</span>
	<ul class="list-unstyled">
	  <li class="active"><a href="index"> <i class="icon-home"></i>Home</a></li>
	  <li><a href="UserIndex"> <i class="icon-user"></i>User</a></li>
	  <li><a href="ProductIndex"> <i class="icon-padnote"></i>Product </a></li>
	  <li><a href="CategoriesIndex"> <i class="icon-windows"></i>Categories</a></li>
	  <li><a href="CustomerIndex"> <i class="icon-user"></i>Customer</a></li>
	  <li><a href="SalesIndex"> <i class="icon-contract"></i>Sales</a></li>
	  <li><a href="PosIndex"> <i class="icon-paper-and-pencil"></i>POS</a></li>
	</ul>
  </nav>
  <!-- Sidebar Navigation end-->
	<?php /**PATH C:\xampp\htdocs\laravelUTS\resources\views/admin/sidebar.blade.php ENDPATH**/ ?>