<?php $__env->startSection('judul'); ?>
     <center><h2 class="h5 no-margin-bottom">Customer Input</h2></center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="col-lg-12">
	<div class="block margin-bottom-sm">
	 <div class="title"><strong>Please Fill The BOX</strong></div>
		<?php $__currentLoopData = $customer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form class="form-horizontal" action="CustomerUpdate" method="post">
		<?php echo e(@csrf_field()); ?>

	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Customer Id</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="idcus" id="idcus" value="<?php echo e($cus->CUSTOMER_ID); ?>">
		</div>
	  </div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">First Name</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="firstcus" id="firstcus" value="<?php echo e($cus->FIRST_NAME); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Last Name</label>
			<div class="col-sm-9">
		 	 <input type="text" class="form-control" name="lastcus" id="lastcus" value="<?php echo e($cus->LAST_NAME); ?>">
			</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
	 	<label class="col-sm-3 form-control-label">Phone</label>
	  	<div class="col-sm-9">
			<input type="text" class="form-control" name="phonecus" id="phonecus" value="<?php echo e($cus->PHONE); ?>"><small class="help-block-none">Input with number</small>
	 	 </div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Email</label>
		<div class="col-sm-9">
		  <input type="email" class="form-control" name="emailcus" id="emailcus" value="<?php echo e($cus->PHONE); ?>">
		</div>
	  </div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Street</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="streetcus" id="namecus" value="<?php echo e($cus->STREET); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">City</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="citycus" id="citycus" value="<?php echo e($cus->CITY); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">State</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="statecus" id="statecus" value="<?php echo e($cus->STATE); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Zip Code</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="zccus" id="zccus" value="<?php echo e($cus->ZIP_CODE); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	<center><input type="submit" value="Save" class="btn btn-primary"></center>
	</form>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div>
<!-- Modal-->
<div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
  <div role="document" class="modal-dialog modal-sm">
	<div class="modal-content" >
	  <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Add a new User</strong>
		<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
	  </div>
	  <div class="modal-body">
		  <h2>Are You Sure To Add This Data?</h2>
	  </div>
	  <div class="modal-footer">
		<a href="CustomerIndex"><button type="submit" class="btn btn-primary">Yes</button></a>
		<button type="button" data-dismiss="modal" class="btn btn-info">Add More</button>
	  </div>
	</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelUTS\resources\views/Master/Customer/Customer_edit.blade.php ENDPATH**/ ?>