<?php $__env->startSection('judul'); ?>
     <center><h2 class="h5 no-margin-bottom">Product Edit</h2></center>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('konten'); ?>
<div class="col-lg-12">
	<div class="block margin-bottom-sm">
	 <div class="title"><strong>Please Fill The BOX</strong></div>
		<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	<form class="form-horizontal" action="ProductUpdate" method="post">
			<?php echo e(@csrf_field()); ?>

	  <div class="form-group row" >
		<label class="col-sm-3 form-control-label">Product Id</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="idpr" id="idpr" value="<?php echo e($pr->PRODUCT_ID); ?>">
		</div>
	  </div>
	  <div class="form-group row" >
		<label class="col-sm-3 form-control-label">Category Id</label>
		<div class="col-sm-9">
		  <input type="text" class="form-control" name="idcatpr" id="idcatpr" value="<?php echo e($pr->CATEGORY_ID); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Product Name</label>
		<div class="col-sm-9">
		 <input type="text" class="form-control" name="prname" id="prname" value="<?php echo e($pr->PRODUCT_NAME); ?>">
		</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
	  <div class="input-group">
		  <label class="col-sm-3 form-control-label">Product Price</label>
		  <div class="input-group-prepend"><span class="input-group-text">Rp.</span></div>
		  	<input type="text" class="col-sm-2 form-control" name="prprice" id="prprice" value="<?php echo e($pr->PRODUCT_PRICE); ?>">
		  <div class="input-group-append"><span class="input-group-text">.00</span></div>
		  </div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
		<label class="col-sm-3 form-control-label">Product Stock</label>
			<div class="col-sm-3">
		 	 <input type="number" class="form-control" name="prstock" id="prstock" value="<?php echo e($pr->PRODUCT_STOCK); ?>">
			</div>
	  </div>
	  <div class="line"></div>
	  <div class="form-group row">
	 	<label class="col-sm-3 form-control-label">Explenation</label>
	  	<div class="col-sm-9">
			<input type="text" class="form-control" name="prex" id="prex" value="<?php echo e($pr->EXPLANATION); ?>">
	 	 </div>
	  </div>
	  <div class="line"></div>
	<center><input type="submit" value="Save" class="btn btn-primary"></center>
	</form>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
</div>
<!-- Modal-->
<div id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true" class="modal fade text-left">
  <div role="document" class="modal-dialog modal-sm">
	<div class="modal-content" >
	  <div class="modal-header"><strong id="exampleModalLabel" class="modal-title">Add a new Product</strong>
		<button type="button" data-dismiss="modal" aria-label="Close" class="close"><span aria-hidden="true">×</span></button>
	  </div>
	  <div class="modal-body">
		  <h2>Are You Sure To Add This Data?</h2>
	  </div>
	  <div class="modal-footer">
		<a href="ProductIndex"><button type="submit" class="btn btn-primary">Yes</button></a>
		<button type="button" data-dismiss="modal" class="btn btn-info">Add More</button>
	  </div>
	</div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelUTS\resources\views/Master/Product/Product_edit.blade.php ENDPATH**/ ?>